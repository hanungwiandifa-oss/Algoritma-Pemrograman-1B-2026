reguler = 40000
vip = 75000
vvip = 100000

reguler=input("masukkan jumlah pembeli")
vip=input("masukkan jumlah pembeli")
vvip=input("masukkan jumlah pembeli")
